Migration to Prod Status 
- organizations [done]
- credentials [done]
- credentials manual update [done] 
	- use sas-gitlab-credentials for projects where we need following credentials
		source control: gitlab_3t_awx 
		qnt-gitlab-credentials 
		vault1 pass: 61Ede)H)B(H
		vault2 pass: !S@st3am!
		
		tower_username: admin
		tower_password: cnc-ansible123
		ldap_bind_username: svctowerldapbind
		ldap_bind_password: Ev4o8^MA!qV(
		splunk_username:
		splunk_password: d51b88e5-dbed-4dfc-a96f-b3f7a652ba89
		
- teams and roles *
	since roles are dependant on the temlates so will need to run teams import again after templates 
- inventories [done]
- inventories sources  [done]
- inventories hosts [can't see same number of hosts as in production]
- inventories groups [some groups are missing]
- projects [done]
- job templates  [done]
- workflow templates [done]

Migration to DR status 
- organizations [done]
- credentials [done]
- manual update [done] 
	- use sas-gitlab-credentials for projects where we need following credentials
		source control: gitlab_3t_awx 
		qnt-gitlab-credentials 
		vault1 pass: 61Ede)H)B(H
		vault2 pass: !S@st3am!
		
		tower_username: admin
		tower_password: cnc-ansible123
		ldap_bind_username: svctowerldapbind
		ldap_bind_password: Ev4o8^MA!qV(
		splunk_username:
		splunk_password: d51b88e5-dbed-4dfc-a96f-b3f7a652ba89
		
- teams and roles 
	since roles are dependant on the temlates so will need to run teams import again after templates 
- inventories [done]
- inventories sources [done]
- inventories hosts [done]
- inventories groups [done]
- projects [done]
- job templates [done]
- workflow templates *




psvuk3lapa011.cmc.local:/nfs_shares nfs4
psvuk3lapa011.cmc.local:/nfs_shares /var/lib/pulp nfs defaults 0 0

sudo yum -y install nfs-utils && sudo mkdir /var/lib/pulp && sudo chmod 777 /var/lib/pulp
sudo firewall-cmd --permanent --add-service=
sudo mount -t nfs4 psvuk2lapa011.cmc.local:nfs_shares/ /var/lib/pulp
psvuk2lapa011.cmc.local:/nfs_shares /var/lib/pulp nfs defaults 0 0



- migrate-host-groups.yml
- migrate-inventory-hosts.yml
- migrate-inventory-sources.yml
- migrate-inventory.yml
- migrate-organizations.yml
- migrate-projects.yml
- migrate-selected-job-templates.yml
- migrate-selected-workflow-templates.yml
- migrate-teams.yml


 cert: /etc/receptor/tls/psvuk3lapa001.cmc.local.crt
 key: /etc/receptor/tls/psvuk3lapa001.cmc.local.key
 Mesh CA cert: /etc/receptor/tls/ca/
 openssl crl2pkcs7 -nocrl -certfile /etc/pki/tls/certs/ca-bundle.crt | openssl pkcs7 -print_certs | grep subject | grep -i Ansible
 
 
 Can't copy ssh key to the following hosts 
 psvuk3lapa001.cmc.local
 psvuk7lapa021.cmc.local

satelite credentials:  vH20ab@iD-9p
Machine Svcawxapproot:  LBek9Am@9LL0
Source Control: gitlab_3t_awx:  FicKi2^B)GQa
svcawxaaproot-dmz:  LBek9Am@9LL0
vault1 team generic: 61Ede)H)B(H
vault2 weka vault: !S@st3am!
9PmcR%hR

Logging Details
aggregator:https://lhf.splunk.app.cmc.local:8088/services/collector/event
Logging: awx, activity_strea,  job_events, system_tracking
ProtoCol: https/https
Threshold level: info 
Token: d51b88e5-dbed-4dfc-a96f-b3f7a652ba89

Project sync failures

Prophet Quant Setup@12:04:26	
Prophet Quant Test
prj:3t/trep_test



sudo ls /var/lib/awx/projects/.__awx_cache/_24__prjsasvmware_build/865/requirements_roles/dns_management
